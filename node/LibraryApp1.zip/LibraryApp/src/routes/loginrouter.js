var express = require('express');
var loginrouter = express.Router();


function router(nav) {
    loginrouter.route('/')
        .get((req, res) => {
            res.render('login.ejs', {
                nav,
                title: "LOGIN",

            })
        })
        return loginrouter;
}
module.exports = router;