var express = require('express');
var signuprouter = express.Router();






function router(nav) {
    signuprouter.route('/')
        .get((req, res) => {
            res.render('signup.ejs', {
                nav,
                title: "SIGNUP",

            })
        })
    signuprouter.route("/signedup")
    .post(function (req, res) {
        res.render("home.ejs",
            {
                nav,
                title: "WELCOME TO LIBRARY",

            })

    })
    return signuprouter;
}
module.exports = router;