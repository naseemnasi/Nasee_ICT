const mongoose=require('mongoose')

var booksModel=mongoose.model('books',{
    title:String,
    genere:String,
    auther:String,
    image:String

})
module.exports={booksModel}