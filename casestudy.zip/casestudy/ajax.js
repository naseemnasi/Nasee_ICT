$(document).ready(function(){
    $ajax=
})